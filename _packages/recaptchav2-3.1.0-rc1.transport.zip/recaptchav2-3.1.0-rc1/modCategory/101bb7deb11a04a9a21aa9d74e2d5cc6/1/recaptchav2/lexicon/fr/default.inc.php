<?php
/**
 * French Lexicon Entries for recaptchav2
 *
 * @package recaptchav2
 * @subpackage lexicon
 *
 */
// EXAMPLE: $_lang[''] = '';
$_lang['recaptchav2.technical_error_message'] = 'Désolé, une erreur s\'est produite lors de la soumission de votre formulaire. Veuillez utiliser l\'un des contacts de cette page à la place.';
$_lang['recaptchav2.recaptcha_error_message'] = 'S\'il vous plaît, cochez la case : Je ne suis pas un robot.';
$_lang['recaptchav2.recaptchav3_error_message'] = 'Désolé, une erreur.';

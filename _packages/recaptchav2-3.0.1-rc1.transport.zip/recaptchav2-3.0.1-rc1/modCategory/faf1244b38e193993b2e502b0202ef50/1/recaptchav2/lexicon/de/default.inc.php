<?php
/**
 * German Lexicon Entries for recaptchav2
 *
 * @package recaptchav2
 * @subpackage lexicon
 *
 */
// EXAMPLE: $_lang[''] = '';
$_lang['recaptchav2.technical_error_message'] = 'Beim Absenden des Formulars ist ein Fehler aufgetreten. Bitte verwenden Sie stattdessen einen der Kontakte auf dieser Seite.';
$_lang['recaptchav2.recaptcha_error_message'] = 'Bitte aktivieren Sie die Checkbox im ReCaptcha Bild.';
